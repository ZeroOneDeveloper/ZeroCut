from .core import LifeCut


def __call__():
    return LifeCut()
